# Your name: Ken Ma
# Your class-section: SECTION 1

# Your program!
nbin = input("Enter common name: ") #allows user to enter name of something or someone
nbout = ((["Hello my name is "+nbin])*len(nbin)) #name badge as many times as the length of input (letters)
print(nbout) #display of nbout, which is name badge times letter length of name
