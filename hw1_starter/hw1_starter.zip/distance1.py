# Your name: Ken Ma
# Your class-section: SECTION 1

# Your program!
d1in = float(input("Please enter number of meters: ")) #allows user to enter number of meters
d1out = int(d1in//0.9144) #convert meters to yards
print("The full number of yards is",d1out) #display full measurements to yards from meters
